// ===================================================================
// Campus One — app.js
// Talks to: Supabase (auth/db/storage) + Netlify functions under /api/*
// ===================================================================

const cfg = window.CAMPUS_ONE_CONFIG || {};
const supabase = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey);

let state = {
  user: null,
  profile: null,
  room: null,
  view: "feed",
  crPinVerifiedThisSession: false,
  pendingSignupRole: null,
};

// ---------------------------------------------------------------
// small utilities
// ---------------------------------------------------------------
function $(sel, root = document) { return root.querySelector(sel); }
function $all(sel, root = document) { return [...root.querySelectorAll(sel)]; }

function showScreen(id) {
  $all(".screen").forEach((s) => { s.hidden = s.id !== id; });
}

function toast(message, type = "ok") {
  const host = $("#toastHost");
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  el.textContent = message;
  host.appendChild(el);
  setTimeout(() => el.remove(), 4200);
}

function showMsg(el, text, kind = "error") {
  el.textContent = text;
  el.className = `msg ${kind}`;
  el.hidden = !text;
}

async function sha256Hex(text) {
  const data = new TextEncoder().encode(text);
  const hash = await crypto.subtle.digest("SHA-256", data);
  return [...new Uint8Array(hash)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function roomCode() {
  const letters = "ABCDEFGHJKLMNPQRSTUVWXYZ";
  const digits = "23456789";
  const pick = (chars, n) => Array.from({ length: n }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
  return `${pick(letters, 3)}-${pick(digits + letters, 4)}`;
}

function fmtDate(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  return d.toLocaleDateString("en-IN", { day: "numeric", month: "short" });
}

async function apiCall(path, payload) {
  const res = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload || {}),
  });
  let data = {};
  try { data = await res.json(); } catch { /* ignore */ }
  if (!res.ok) throw new Error(data.error || "Request failed.");
  return data;
}

// ---------------------------------------------------------------
// nav bar (auth-state dependent)
// ---------------------------------------------------------------
function renderNav() {
  const el = $("#navRight");
  if (!state.user) {
    el.innerHTML = `
      <button class="btn btn-ghost btn-small" data-action="show-auth" data-tab="login">Log in</button>
      <button class="btn btn-primary btn-small" data-action="show-auth" data-tab="signup">Sign up</button>`;
  } else {
    const roleLabel = state.profile?.role === "cr" ? "CR" : "Student";
    el.innerHTML = `
      <span class="pill">${roleLabel}</span>
      <span class="muted" style="margin:0">${state.profile?.full_name || ""}</span>
      <button class="btn btn-ghost btn-small" id="navLogout">Log out</button>`;
    $("#navLogout")?.addEventListener("click", logout);
  }
}

// ---------------------------------------------------------------
// AUTH
// ---------------------------------------------------------------
function setAuthTab(tab) {
  $all(".tab").forEach((t) => t.classList.toggle("active", t.dataset.authtab === tab));
  $("#signupForm").hidden = tab !== "signup";
  $("#loginForm").hidden = tab !== "login";
}

async function handleSignup(e) {
  e.preventDefault();
  const form = e.target;
  const errEl = $("#signupError");
  showMsg(errEl, "");
  const btn = $("#signupSubmit");
  btn.disabled = true;

  const fullName = form.fullName.value.trim();
  const email = form.email.value.trim();
  const password = form.password.value;
  const college = form.college.value.trim();
  const batch = form.batch.value.trim();
  const role = form.querySelector('input[name="role"]:checked').value;

  try {
    const { data, error } = await supabase.auth.signUp({ email, password });
    if (error) {
      if (/already registered|already exists/i.test(error.message)) {
        showMsg(errEl, "An account already exists for this email — try logging in instead.");
      } else if (/password/i.test(error.message)) {
        showMsg(errEl, "Password needs to be at least 6 characters.");
      } else {
        showMsg(errEl, error.message);
      }
      return;
    }

    if (!data.session) {
      showMsg(errEl, "Check your inbox to confirm your email, then come back and log in.", "wait");
      return;
    }

    // we have a live session — create the profile row now
    const { error: profileErr } = await supabase.from("profiles").insert({
      id: data.user.id,
      full_name: fullName,
      role,
      college,
      batch,
    });
    if (profileErr) {
      showMsg(errEl, "Account created, but the profile couldn't be saved. Try logging in.");
      return;
    }

    await loadUserAndRoute();
  } catch (err) {
    showMsg(errEl, err.message || "Something went wrong. Try again.");
  } finally {
    btn.disabled = false;
  }
}

async function handleLogin(e) {
  e.preventDefault();
  const form = e.target;
  const errEl = $("#loginError");
  showMsg(errEl, "");
  const btn = $("#loginSubmit");
  btn.disabled = true;

  const email = form.email.value.trim();
  const password = form.password.value;

  try {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      if (/email not confirmed/i.test(error.message)) {
        showMsg(errEl, "Please confirm your email first — check your inbox for the confirmation link.");
      } else if (/invalid login credentials/i.test(error.message)) {
        showMsg(errEl, "Wrong email or password. Try again.");
      } else {
        showMsg(errEl, error.message);
      }
      return;
    }
    await loadUserAndRoute();
  } catch (err) {
    showMsg(errEl, err.message || "Couldn't log in. Try again.");
  } finally {
    btn.disabled = false;
  }
}

async function logout() {
  await supabase.auth.signOut();
  state = { ...state, user: null, profile: null, room: null, crPinVerifiedThisSession: false };
  renderNav();
  showScreen("screen-landing");
}

// ---------------------------------------------------------------
// ROUTING after auth
// ---------------------------------------------------------------
async function loadUserAndRoute() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) { showScreen("screen-landing"); return; }
  state.user = user;

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle();
  state.profile = profile;
  renderNav();

  if (!profile) {
    // shouldn't normally happen — send back to signup to complete profile
    showScreen("screen-auth");
    setAuthTab("signup");
    return;
  }

  if (!profile.room_code) {
    if (profile.role === "cr") {
      showScreen("screen-create-room");
    } else {
      showScreen("screen-join-room");
    }
    return;
  }

  const { data: room } = await supabase.from("rooms").select("*").eq("code", profile.room_code).maybeSingle();
  state.room = room;
  enterDashboard();
}

// ---------------------------------------------------------------
// CREATE ROOM (CR)
// ---------------------------------------------------------------
async function handleCreateRoom(e) {
  e.preventDefault();
  const form = e.target;
  const errEl = $("#createRoomError");
  showMsg(errEl, "");
  const btn = $("#createRoomSubmit");

  const pin = form.pin.value.trim();
  const pinConfirm = form.pinConfirm.value.trim();
  if (!/^\d{4,8}$/.test(pin)) { showMsg(errEl, "PIN must be 4–8 digits."); return; }
  if (pin !== pinConfirm) { showMsg(errEl, "PINs don't match."); return; }

  btn.disabled = true;
  try {
    const pinHash = await sha256Hex(pin);
    let code, insertError;
    for (let attempt = 0; attempt < 5; attempt += 1) {
      code = roomCode();
      const { error } = await supabase.from("rooms").insert({
        code,
        college: state.profile.college,
        batch: state.profile.batch,
        cr_pin_hash: pinHash,
        created_by: state.user.id,
      });
      insertError = error;
      if (!error) break;
      if (!/duplicate key|already exists/i.test(error.message || "")) break;
    }
    if (insertError) { showMsg(errEl, "Couldn't create the room. Try again."); return; }

    await supabase.from("profiles").update({ room_code: code }).eq("id", state.user.id);
    state.profile.room_code = code;

    $("#createdRoomCode").textContent = code;
    showScreen("screen-room-created");
  } catch (err) {
    showMsg(errEl, err.message || "Something went wrong.");
  } finally {
    btn.disabled = false;
  }
}

// ---------------------------------------------------------------
// JOIN ROOM (student)
// ---------------------------------------------------------------
async function handleJoinRoom(e) {
  e.preventDefault();
  const form = e.target;
  const msgEl = $("#joinRoomMsg");
  showMsg(msgEl, "");
  const btn = $("#joinRoomSubmit");
  btn.disabled = true;

  const code = form.roomCode.value.trim().toUpperCase();
  try {
    const { data: room, error } = await supabase.from("rooms").select("*").eq("code", code).maybeSingle();
    if (error) { showMsg(msgEl, "Couldn't check that code right now. Try again."); return; }
    if (!room) {
      showMsg(msgEl, "No room matches this code. Double-check it with your CR — codes mix letters and numbers and are easy to mistype.");
      return;
    }
    if (room.cr_locked) {
      showMsg(msgEl, "This room is frozen and isn't accepting new members right now. Ask your CR to unfreeze it.");
      return;
    }

    await supabase.from("profiles").update({ room_code: code }).eq("id", state.user.id);
    state.profile.room_code = code;
    state.room = room;
    showMsg(msgEl, `You're in. Welcome to ${room.college}${room.batch ? " · " + room.batch : ""}.`, "ok");
    setTimeout(enterDashboard, 700);
  } catch (err) {
    showMsg(msgEl, err.message || "Something went wrong.");
  } finally {
    btn.disabled = false;
  }
}

// ---------------------------------------------------------------
// CR PIN MODAL (reusable)
// ---------------------------------------------------------------
function requireCrPin() {
  return new Promise((resolve) => {
    const overlay = $("#pinModal");
    const input = $("#pinModalInput");
    const msg = $("#pinModalMsg");
    input.value = "";
    showMsg(msg, "");
    overlay.hidden = false;
    input.focus();

    const cleanup = () => {
      overlay.hidden = true;
      confirmBtn.removeEventListener("click", onConfirm);
      cancelBtn.removeEventListener("click", onCancel);
    };
    const onConfirm = async () => {
      const { data: freshRoom } = await supabase.from("rooms").select("cr_pin_hash").eq("code", state.room.code).maybeSingle();
      const hash = await sha256Hex(input.value.trim());
      if (!freshRoom || hash !== freshRoom.cr_pin_hash) {
        showMsg(msg, "That PIN doesn't match this room. Check with your records and try again.");
        return;
      }
      cleanup();
      resolve(true);
    };
    const onCancel = () => { cleanup(); resolve(false); };

    var confirmBtn = $("#pinModalConfirm");
    var cancelBtn = $("#pinModalCancel");
    confirmBtn.addEventListener("click", onConfirm);
    cancelBtn.addEventListener("click", onCancel);
  });
}

// ---------------------------------------------------------------
// DASHBOARD SHELL
// ---------------------------------------------------------------
function enterDashboard() {
  $("#dashCollege").textContent = `${state.room.college}${state.room.batch ? " · " + state.room.batch : ""}`;
  $("#dashRoomCode").textContent = state.room.code;
  const statusPill = $("#dashRoomStatus");
  statusPill.textContent = state.room.cr_locked ? "frozen" : "active";
  statusPill.className = `pill ${state.room.cr_locked ? "frozen-pill" : "active-pill"}`;

  $all(".cr-only").forEach((el) => { el.hidden = state.profile.role !== "cr"; });

  showScreen("screen-dashboard");
  switchView("feed");
}

async function switchView(view) {
  if (view === "mission" && state.profile.role === "cr" && !state.crPinVerifiedThisSession) {
    const ok = await requireCrPin();
    if (!ok) return;
    state.crPinVerifiedThisSession = true;
  }

  state.view = view;
  $all(".dash-link").forEach((b) => b.classList.toggle("active", b.dataset.view === view));
  $all(".view").forEach((v) => { v.hidden = v.id !== `view-${view}`; });

  if (view === "feed") loadFeed();
  if (view === "mission") loadMission();
  if (view === "board") loadBoard();
  if (view === "notes") loadNotes();
}

// ---------------------------------------------------------------
// FEED
// ---------------------------------------------------------------
function categoryPillClass(priority) {
  if (priority === "Urgent") return "frozen-pill";
  if (priority === "Low") return "";
  return "active-pill";
}

async function loadFeed() {
  const list = $("#feedList");
  list.innerHTML = "";
  const { data: anns, error } = await supabase
    .from("announcements")
    .select("*")
    .eq("room_code", state.room.code)
    .order("pinned", { ascending: false })
    .order("created_at", { ascending: false });

  $("#feedEmpty").hidden = !!(anns && anns.length);
  if (error || !anns) return;

  const { data: myResponses } = await supabase
    .from("announcement_responses")
    .select("announcement_id, response")
    .eq("user_id", state.user.id);
  const responseMap = new Map((myResponses || []).map((r) => [r.announcement_id, r.response]));

  anns.forEach((a) => {
    list.appendChild(renderAnnouncementCard(a, responseMap.get(a.id)));
    if (a.author_id !== state.user.id) {
      supabase.from("announcement_reads").upsert(
        { announcement_id: a.id, user_id: state.user.id },
        { onConflict: "announcement_id,user_id", ignoreDuplicates: true }
      );
    }
  });
}

function renderAnnouncementCard(a, myResponse) {
  const el = document.createElement("div");
  el.className = `ann-card${a.pinned ? " pinned" : ""}`;
  el.innerHTML = `
    <div class="ann-head">
      <div>
        <p class="ann-title">${a.pinned ? "📌 " : ""}${escapeHtml(a.title || a.category)}</p>
        <p class="ann-meta">${fmtDate(a.created_at)}${a.due_at ? " · due " + fmtDate(a.due_at) : ""}</p>
      </div>
      <div class="ann-tags">
        <span class="pill ${categoryPillClass(a.priority)}">${escapeHtml(a.priority)}</span>
        <span class="pill">${escapeHtml(a.category)}</span>
      </div>
    </div>
    <p class="ann-body">${escapeHtml(a.message)}</p>
    ${a.requires_response ? `
      <div class="ann-actions" data-ann-id="${a.id}">
        <button class="resp-btn${myResponse === "attending" ? " selected" : ""}" data-resp="attending">Attending</button>
        <button class="resp-btn${myResponse === "maybe" ? " selected" : ""}" data-resp="maybe">Maybe</button>
        <button class="resp-btn${myResponse === "declined" ? " selected" : ""}" data-resp="declined">Not attending</button>
      </div>` : ""}
  `;
  el.querySelectorAll(".resp-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const response = btn.dataset.resp;
      await supabase.from("announcement_responses").upsert(
        { announcement_id: a.id, user_id: state.user.id, response },
        { onConflict: "announcement_id,user_id" }
      );
      el.querySelectorAll(".resp-btn").forEach((b) => b.classList.toggle("selected", b === btn));
      toast("Response saved.");
    });
  });
  return el;
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}

// ---------------------------------------------------------------
// MISSION CONTROL (CR)
// ---------------------------------------------------------------
async function handleAnnounceSubmit(e) {
  e.preventDefault();
  const form = e.target;
  const errEl = $("#announceError");
  showMsg(errEl, "");

  const title = form.title.value.trim();
  const message = form.message.value.trim();
  if (!message) { showMsg(errEl, "Write a message before posting."); return; }

  const payload = {
    title: title || null,
    message,
    category: form.category.value,
    priority: form.priority.value,
    author_id: state.user.id,
    room_code: state.room.code,
    pinned: form.pinned.checked,
    requires_response: form.requiresResponse.checked,
    due_at: form.dueAt.value || null,
  };

  const { error } = await supabase.from("announcements").insert(payload);
  if (error) { showMsg(errEl, "Couldn't post that. Try again."); return; }

  form.reset();
  form.requiresResponse.checked = true;
  toast("Posted to the room.");
  loadMission();
}

async function loadMission() {
  const list = $("#missionList");
  list.innerHTML = "";
  const freezeBtn = $("#freezeToggleBtn");
  freezeBtn.textContent = state.room.cr_locked ? "Unfreeze room" : "Freeze room";

  const { count: memberCount } = await supabase
    .from("profiles")
    .select("id", { count: "exact", head: true })
    .eq("room_code", state.room.code);

  const { data: anns } = await supabase
    .from("announcements")
    .select("*")
    .eq("room_code", state.room.code)
    .order("created_at", { ascending: false });

  if (!anns || !anns.length) {
    list.innerHTML = `<p class="muted">You haven't posted anything yet — use the composer above.</p>`;
    return;
  }

  for (const a of anns) {
    const [{ count: readCount }, { data: responses }] = await Promise.all([
      supabase.from("announcement_reads").select("user_id", { count: "exact", head: true }).eq("announcement_id", a.id),
      supabase.from("announcement_responses").select("response").eq("announcement_id", a.id),
    ]);
    const tally = { attending: 0, maybe: 0, declined: 0 };
    (responses || []).forEach((r) => { tally[r.response] = (tally[r.response] || 0) + 1; });

    const el = renderAnnouncementCard(a, null);
    const track = document.createElement("div");
    track.className = "track-row";
    track.innerHTML = `
      <span><strong>${readCount || 0}</strong> / ${memberCount || 0} read</span>
      ${a.requires_response ? `<span><strong>${tally.attending}</strong> attending</span><span><strong>${tally.maybe}</strong> maybe</span><span><strong>${tally.declined}</strong> not attending</span>` : ""}
    `;
    el.appendChild(track);
    list.appendChild(el);
  }
}

async function toggleFreeze() {
  const ok = await requireCrPin();
  if (!ok) return;
  const newVal = !state.room.cr_locked;
  const { error } = await supabase.from("rooms").update({ cr_locked: newVal }).eq("code", state.room.code);
  if (error) { toast("Couldn't update the room right now.", "error"); return; }
  state.room.cr_locked = newVal;
  const statusPill = $("#dashRoomStatus");
  statusPill.textContent = newVal ? "frozen" : "active";
  statusPill.className = `pill ${newVal ? "frozen-pill" : "active-pill"}`;
  $("#freezeToggleBtn").textContent = newVal ? "Unfreeze room" : "Freeze room";
  toast(newVal ? "Room frozen — no new members can join." : "Room unfrozen.");
}

// ---------------------------------------------------------------
// CR BOARD
// ---------------------------------------------------------------
async function loadBoard() {
  const isCr = state.profile.role === "cr";
  $("#newBoardPostBtn").hidden = !isCr;

  const { data: posts } = await supabase
    .from("cr_posts")
    .select("*")
    .eq("room_code", state.room.code)
    .order("pinned", { ascending: false })
    .order("created_at", { ascending: false });

  const list = $("#boardList");
  list.innerHTML = "";
  $("#boardEmpty").hidden = !!(posts && posts.length);
  (posts || []).forEach((p) => {
    const el = document.createElement("div");
    el.className = `ann-card${p.pinned ? " pinned" : ""}`;
    el.innerHTML = `
      <p class="ann-title">${p.pinned ? "📌 " : ""}${escapeHtml(p.title)}</p>
      <p class="ann-meta">${fmtDate(p.created_at)}</p>
      <p class="ann-body">${escapeHtml(p.body)}</p>`;
    list.appendChild(el);
  });
}

async function handleBoardSubmit(e) {
  e.preventDefault();
  const form = e.target;
  const errEl = $("#boardError");
  showMsg(errEl, "");

  const { error } = await supabase.from("cr_posts").insert({
    title: form.title.value.trim(),
    body: form.body.value.trim(),
    college: state.room.college,
    batch: state.room.batch,
    room_code: state.room.code,
    pinned: form.pinned.checked,
    author_id: state.user.id,
  });
  if (error) { showMsg(errEl, "Couldn't post that. Try again."); return; }
  form.reset();
  $("#boardComposerWrap").hidden = true;
  toast("Posted to CR Board.");
  loadBoard();
}

// ---------------------------------------------------------------
// NOTES MARKETPLACE
// ---------------------------------------------------------------
let notesCache = [];

async function loadNotes() {
  const { data: notes } = await supabase
    .from("notes")
    .select("*")
    .eq("room_code", state.room.code)
    .order("created_at", { ascending: false });
  notesCache = notes || [];

  const grid = $("#notesList");
  grid.innerHTML = "";
  $("#notesEmpty").hidden = !!(notes && notes.length);
  (notes || []).forEach((n) => {
    const el = document.createElement("div");
    el.className = "note-card";
    el.innerHTML = `
      <h4>${escapeHtml(n.title)}</h4>
      <span class="muted">${escapeHtml(n.subject)}</span>
      <span class="note-price">₹${n.price}</span>`;
    el.addEventListener("click", () => openNoteDetail(n.id));
    grid.appendChild(el);
  });
}

function openNoteDetail(noteId) {
  const note = notesCache.find((n) => n.id === noteId);
  if (!note) return;
  renderNoteDetail(note);
  $("#noteDetailModal").hidden = false;
}

async function renderNoteDetail(note) {
  const body = $("#noteDetailBody");
  const { data: purchases } = await supabase
    .from("note_purchases")
    .select("purchase_type")
    .eq("note_id", note.id)
    .eq("buyer_id", state.user.id);
  const hasFile = (purchases || []).some((p) => p.purchase_type === "file");
  const hasAi = (purchases || []).some((p) => p.purchase_type === "ai");
  const isOwner = note.uploader_id === state.user.id;

  let fileSection = "";
  if (note.file_path) {
    if (hasFile || isOwner) {
      const { data: signed } = await supabase.storage.from("notes").createSignedUrl(note.file_path, 120);
      fileSection = `<a class="btn btn-primary btn-small" href="${signed?.signedUrl || "#"}" target="_blank" rel="noopener">Download file</a>`;
    } else {
      fileSection = `<button class="btn btn-primary btn-small" data-buy="file">Unlock file — ₹${note.price}</button>`;
    }
  }

  let aiSection = "";
  if (hasAi || isOwner) {
    aiSection = renderAiPack(note);
  } else {
    aiSection = `<button class="btn btn-ghost btn-small" data-buy="ai">Unlock AI summary, quiz plan &amp; key dates — ₹20</button>`;
  }

  body.innerHTML = `
    <p class="eyebrow">${escapeHtml(note.subject)}</p>
    <h3>${escapeHtml(note.title)}</h3>
    <div class="chip-row">${fileSection}${aiSection && !hasAi && !isOwner ? "" : ""}</div>
    <div class="note-detail-section">
      ${!hasAi && !isOwner ? aiSection : ""}
    </div>
    ${(hasAi || isOwner) ? `<div class="note-detail-section">${aiSection}</div>` : ""}
    <div class="modal-actions">
      <button class="btn btn-ghost" id="noteDetailClose" type="button">Close</button>
    </div>
  `;

  $("#noteDetailClose").addEventListener("click", () => { $("#noteDetailModal").hidden = true; });
  body.querySelector('[data-buy="file"]')?.addEventListener("click", () => buyNote(note, "file"));
  body.querySelector('[data-buy="ai"]')?.addEventListener("click", () => buyNote(note, "ai"));
}

function renderAiPack(note) {
  const points = (note.ai_summary_points || []).map((p) => `<li><strong>${escapeHtml(p.importance)}:</strong> ${escapeHtml(p.point)}</li>`).join("");
  const plan = (note.ai_study_plan || []).map((d) => `<li>Day ${d.day} — ${escapeHtml(d.focus)} (${d.est_minutes || "~"} min)</li>`).join("");
  const dates = (note.ai_key_dates || []).map((d) => `<li>${escapeHtml(d.date)}: ${escapeHtml(d.description)}</li>`).join("");
  const topics = (note.ai_topics || []).map((t) => `<span class="chip">${escapeHtml(t.name)} · ${escapeHtml(t.priority)}</span>`).join(" ");
  return `
    <h5>AI summary</h5><ul>${points || "<li>No summary available.</li>"}</ul>
    <h5>5-day study plan</h5><ul>${plan || "<li>No plan available.</li>"}</ul>
    <h5>Key dates</h5><ul>${dates || "<li>None flagged.</li>"}</ul>
    <h5>Topics</h5><div class="chip-row">${topics}</div>
  `;
}

async function buyNote(note, type) {
  try {
    const amount = type === "file" ? Math.round(note.price * 100) : 2000;
    const order = await apiCall("/api/razorpay/create-order", {
      amount, currency: "INR", type, noteId: note.id,
    });

    const rzp = new Razorpay({
      key: cfg.razorpayKeyId,
      amount: order.amount,
      currency: order.currency,
      order_id: order.id,
      name: "Campus One",
      description: note.title,
      prefill: { name: state.profile.full_name, email: state.user.email },
      theme: { color: "#1B2A4A" },
      handler: async (response) => {
        try {
          const verify = await apiCall("/api/razorpay/verify-payment", {
            razorpay_order_id: response.razorpay_order_id,
            razorpay_payment_id: response.razorpay_payment_id,
            razorpay_signature: response.razorpay_signature,
            purchase: {
              noteId: note.id,
              buyerId: state.user.id,
              purchaseType: type,
              grossAmount: amount,
            },
          });
          if (verify.verified) {
            toast("Unlocked!");
            renderNoteDetail(note);
          } else {
            toast("Payment could not be verified.", "error");
          }
        } catch (err) {
          toast(err.message || "Payment verification failed.", "error");
        }
      },
    });
    rzp.on("payment.failed", () => toast("Payment failed. Try again.", "error"));
    rzp.open();
  } catch (err) {
    toast(err.message || "Couldn't start payment.", "error");
  }
}

async function handleNoteSubmit(e) {
  e.preventDefault();
  const form = e.target;
  const errEl = $("#noteError");
  showMsg(errEl, "");
  const btn = $("#noteSubmit");
  btn.disabled = true;
  btn.textContent = "Listing…";

  try {
    const title = form.title.value.trim();
    const subject = form.subject.value.trim();
    const price = Number(form.price.value);
    const file = form.file.files[0];
    let content = form.content.value.trim();

    if (!content && file && (file.type.startsWith("text/") || /\.txt$/i.test(file.name))) {
      content = await file.text();
    }

    let filePath = null;
    if (file) {
      filePath = `${state.user.id}/${Date.now()}_${file.name}`;
      const { error: upErr } = await supabase.storage.from("notes").upload(filePath, file);
      if (upErr) throw new Error("File upload failed: " + upErr.message);
    }

    const ai = await apiCall("/api/claude-notes", { title, subject, content, fileName: file?.name });

    const { error } = await supabase.from("notes").insert({
      title, subject,
      college: state.room.college,
      room_code: state.room.code,
      uploader_id: state.user.id,
      price, max_price: 199,
      file_path: filePath,
      file_name: file?.name || null,
      ai_summary_points: ai.summary_points || [],
      ai_study_plan: ai.study_plan || [],
      ai_key_dates: ai.key_dates || [],
      ai_topics: ai.topics || [],
    });
    if (error) throw new Error("Couldn't save the listing.");

    form.reset();
    $("#noteModal").hidden = true;
    toast("Notes listed!");
    loadNotes();
  } catch (err) {
    showMsg(errEl, err.message || "Something went wrong.");
  } finally {
    btn.disabled = false;
    btn.textContent = "List notes";
  }
}

// ---------------------------------------------------------------
// WIRE UP EVENTS
// ---------------------------------------------------------------
function wireEvents() {
  document.addEventListener("click", (e) => {
    const actionEl = e.target.closest("[data-action]");
    if (!actionEl) return;
    const action = actionEl.dataset.action;
    if (action === "show-auth") {
      showScreen("screen-auth");
      setAuthTab(actionEl.dataset.tab || "signup");
    }
    if (action === "enter-dashboard") enterDashboard();
  });

  $all(".tab").forEach((t) => t.addEventListener("click", () => setAuthTab(t.dataset.authtab)));
  $("#signupForm").addEventListener("submit", handleSignup);
  $("#loginForm").addEventListener("submit", handleLogin);
  $("#createRoomForm").addEventListener("submit", handleCreateRoom);
  $("#joinRoomForm").addEventListener("submit", handleJoinRoom);
  $("#announceForm").addEventListener("submit", handleAnnounceSubmit);
  $("#boardForm").addEventListener("submit", handleBoardSubmit);
  $("#noteForm").addEventListener("submit", handleNoteSubmit);
  $("#freezeToggleBtn").addEventListener("click", toggleFreeze);
  $("#logoutBtn").addEventListener("click", logout);

  $all(".dash-link").forEach((b) => b.addEventListener("click", () => switchView(b.dataset.view)));

  $("#uploadNoteBtn").addEventListener("click", () => { $("#noteModal").hidden = false; });
  $("#noteModalCancel").addEventListener("click", () => { $("#noteModal").hidden = true; });
  $("#newBoardPostBtn").addEventListener("click", () => {
    $("#boardComposerWrap").hidden = !$("#boardComposerWrap").hidden;
  });

  [$("#noteModal"), $("#noteDetailModal"), $("#pinModal")].forEach((overlay) => {
    overlay.addEventListener("click", (e) => { if (e.target === overlay && overlay.id !== "pinModal") overlay.hidden = true; });
  });
}

// ---------------------------------------------------------------
// BOOT
// ---------------------------------------------------------------
async function boot() {
  wireEvents();
  renderNav();

  const { data: { session } } = await supabase.auth.getSession();
  if (session) {
    await loadUserAndRoute();
  } else {
    showScreen("screen-landing");
  }

  supabase.auth.onAuthStateChange((event) => {
    if (event === "SIGNED_OUT") {
      showScreen("screen-landing");
    }
  });
}

document.addEventListener("DOMContentLoaded", boot);
