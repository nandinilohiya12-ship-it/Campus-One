-- Campus One — storage & performance patch (v2)
-- Run this AFTER your existing supabase-schema.sql. It is additive and
-- safe to run on your live database — it does not touch existing tables,
-- rows, or the schema you already applied.
--
-- WHY THIS IS NEEDED:
-- supabase-schema.sql creates the "notes" and "cr-posts" storage buckets,
-- but never adds Row Level Security policies for storage.objects.
-- Supabase enables RLS on storage.objects by default, so with no policies,
-- every upload and every download against these buckets is silently
-- denied — this is very likely the root of some of the reported
-- "note file" and "AI agent" reliability issues, since a failed file
-- upload can leave a note row with no file_path.

-- ---------- NOTES BUCKET ----------

create policy "Uploader can manage their own note files"
on storage.objects for all to authenticated
using (bucket_id = 'notes' and owner = auth.uid())
with check (bucket_id = 'notes' and owner = auth.uid());

create policy "Buyers can read note files they purchased"
on storage.objects for select to authenticated
using (
  bucket_id = 'notes'
  and exists (
    select 1
    from public.notes n
    join public.note_purchases p on p.note_id = n.id
    where n.file_path = storage.objects.name
      and p.buyer_id = auth.uid()
      and p.purchase_type = 'file'
  )
);

-- ---------- CR-POSTS BUCKET ----------

create policy "CR can manage their own board post files"
on storage.objects for all to authenticated
using (bucket_id = 'cr-posts' and owner = auth.uid())
with check (bucket_id = 'cr-posts' and owner = auth.uid());

create policy "Room members can read CR board files"
on storage.objects for select to authenticated
using (
  bucket_id = 'cr-posts'
  and exists (
    select 1
    from public.cr_posts c
    join public.profiles pr on pr.room_code = c.room_code
    where c.file_path = storage.objects.name
      and pr.id = auth.uid()
  )
);

-- ---------- INDEXES (query performance as rooms grow) ----------

create index if not exists idx_profiles_room_code on public.profiles(room_code);
create index if not exists idx_announcements_room_code on public.announcements(room_code);
create index if not exists idx_announcement_reads_ann on public.announcement_reads(announcement_id);
create index if not exists idx_announcement_responses_ann on public.announcement_responses(announcement_id);
create index if not exists idx_notes_room_code on public.notes(room_code);
create index if not exists idx_cr_posts_room_code on public.cr_posts(room_code);
create index if not exists idx_note_purchases_buyer on public.note_purchases(buyer_id);
