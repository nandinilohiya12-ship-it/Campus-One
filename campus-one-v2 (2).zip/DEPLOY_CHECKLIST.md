# Campus One v2 — Deploy Checklist

This rebuild keeps your real, working backend (Supabase schema, RLS,
Razorpay verification, Gemini AI functions) and replaces the frontend
with a new UI. Your `config.js` already has your live Supabase project
and Razorpay key ID baked in, so most of this is upload-and-go.

## 1. Run one new SQL file in Supabase

Your original `supabase-schema.sql` created the `notes` and `cr-posts`
storage buckets but never added Row Level Security policies for them —
with RLS on by default, that means file upload/download was likely
failing silently. This is probably part of the "AI agent not working
correctly" reports.

**Action:** In the Supabase SQL Editor, run `supabase-storage-policies.sql`
(included in this package). It's additive — safe to run on your live
database, doesn't touch existing data.

Do **not** re-run `supabase-schema.sql` — it's unchanged and already applied.

## 2. Netlify environment variables (should already be set — verify)

In Netlify → Site settings → Environment variables, confirm these exist:

- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `GEMINI_API_KEY`
- `RAZORPAY_KEY_ID`
- `RAZORPAY_KEY_SECRET`

None of these live in any file in this package — they stay server-side only.

## 3. Upload

Replace your repo contents with everything in this package (or push it
to `github.com/nandinilohiya12-ship-it/Campus-One` on `main`), keeping
the same file layout. Netlify will auto-deploy.

Files that changed:
- `index.html`, `style.css`, `app.js` — full rebuild
- `supabase-storage-policies.sql` — new, run once (see step 1)
- `DEPLOY_CHECKLIST.md` — this file

Files kept exactly as-is (already solid, no changes needed):
- `netlify/functions/*` (Gemini AI calls, Razorpay order + verify)
- `supabase-schema.sql`
- `config.js`, `netlify.toml`, `manifest.webmanifest`, `sw.js`, `icons/`

## 4. Known limitations still open (from your PRD — not fixed by this rebuild)

- **Email confirmation**: still needs a custom SMTP provider (e.g. Resend
  free tier) connected in Supabase → Authentication → Email settings
  before you re-enable "Confirm email." This is a dashboard setting, not
  code — nothing in this package can turn it on for you.
- **Razorpay live mode**: still in test mode until you complete business
  KYC with Razorpay. The `rzp_test_...` key in `config.js` only works in
  test mode.
- **AI reliability**: the Gemini functions now have a real content
  fallback if the API call fails, so results should never be blank —
  but if you still see bad output, it's worth checking the Gemini
  dashboard for rate-limit or quota errors.

## 5. What's new in this rebuild

- Explicit failure states instead of silent ones: wrong CR PIN, room
  not found, room frozen, unconfirmed email, wrong password — each
  shows a specific message instead of nothing happening.
- CR PIN is verified once per session before Mission Control opens
  (hash comparison, same as before — never sent or stored in plain text).
- A full new UI across landing, auth, room setup, feed, Mission Control,
  CR Board, and notes marketplace, in one consistent design system.
- Freeze/unfreeze now needs the CR PIN again, matching the "prevents
  unauthorized CR access" goal from your PRD.
