# Campus One Deployment

This folder is a production-ready, mobile-first PWA. Deploy the contents of this folder as the site root. The frontend is static; AI and payment flows run through the included Netlify Functions.

## Quick Deploy

- Netlify (recommended): import the GitHub repository, use publish directory `.` and let `netlify.toml` configure Functions and routes. No build command is required.
- Netlify Drop: suitable for a visual preview only. Serverless AI and Razorpay features require configured environment variables.
- Vercel: the static UI can deploy with `vercel.json`, but migrate the Netlify Functions before using live AI or payments there.

## Public Today Checklist

1. Push this folder to the GitHub repository and connect it to Netlify.
2. Add the required environment variables below in Netlify Site Configuration.
3. Trigger a deploy and verify sign-up, student join, CR room creation, one AI request, and one Razorpay test payment.
4. Open the deployed HTTPS link on mobile and install it from the browser menu.
5. Switch Razorpay to live mode only after business KYC and a full payment-verification test.

## Mobile Install

After deployment, open the HTTPS URL on your phone.

- Android Chrome: menu -> Add to Home screen.
- iPhone Safari: Share -> Add to Home Screen.

## Production Backends

The frontend includes demo fallbacks for the AI features (now backed by Gemini) and Razorpay. It also includes Supabase support.

## Supabase Setup

1. Create a Supabase project.
2. Open Supabase SQL Editor.
3. Run `supabase-schema.sql`.
4. Create real users in Supabase Auth.
5. Insert a matching row in `profiles` for each user.
6. Open `config.js` and set:

```js
window.CAMPUS_ONE_CONFIG = {
  supabaseUrl: "https://YOUR_PROJECT.supabase.co",
  supabaseAnonKey: "YOUR_PUBLISHABLE_ANON_KEY",
  razorpayKeyId: "rzp_live_OR_TEST_KEY_ID",
  demoMode: false
};
```

After this, the profile picker, notes marketplace, CR board, and room-based flows use Supabase data.

## Room and CR Lock Flow

- CR enters college, batch, room code, and CR PIN.
- If the room does not exist, the CR creates it.
- CR can copy the room invite link from the dashboard.
- Students join using the same room code or invite link.
- CR can turn on `Freeze CR access`.
- CR features require the room CR PIN; students cannot self-open CR tools.

For real multi-phone usage, Supabase must be connected because browser storage is local to one phone. The schema includes:

- `rooms`
- `profiles.room_code`
- `announcements.room_code`
- `notes.room_code`
- `cr_posts.room_code`

This package includes Netlify Functions for:

- `/api/claude-notes` for AI summary/chat/study tools (now powered by Google Gemini).
- `/api/razorpay/create-order` for Razorpay order creation.
- `/api/razorpay/verify-payment` for Razorpay signature verification.

Add these in Netlify Site Settings -> Environment Variables:

- `RAZORPAY_KEY_ID`
- `RAZORPAY_KEY_SECRET`
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `GEMINI_API_KEY`

Only `razorpayKeyId` goes in `config.js`. Never put `RAZORPAY_KEY_SECRET` in frontend files.

## Before Public Launch

- Configure a custom Supabase SMTP provider, then enable email confirmation.
- Keep the Supabase service-role key only in Netlify environment variables; it must never appear in `config.js` or a commit.
- Run the SQL schema in the intended Supabase project and confirm Row Level Security is enabled.
- Verify the Razorpay signature endpoint with a test order before enabling live payments.
- Test sign-up, sign-in, room join, read receipts, responses, note upload, purchase, and AI response on Android and iPhone.
- Use Netlify deploy previews for changes. Deploy production from the protected `main` branch only.

## Income Management

Money from real payments settles into the bank account connected to your Razorpay merchant account. Seller earnings are tracked in the app as `70%` of the note sale price, while platform earnings are `30%`. Read `PAYMENTS.md` before enabling live payments.
